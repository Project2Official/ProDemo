//
//  ViewController.swift
//  ProDemo
//
//  Created by NEXT on 04.09.2025.
//

import UIKit

class RootViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let VideoPlayer = UIVideoPlayer(frame: self.view.frame)
        self.view.addSubview(VideoPlayer)
    }
}

