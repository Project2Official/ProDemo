//
//  UIPlayerView.swift
//  ProDemo
//
//  Created by NEXT on 04.09.2025.
//

import UIKit
import AVKit
import AVFoundation
class UIVideoPlayer: UIView {
    var playerLayer = AVPlayerLayer()
    var playerLooper: AVPlayerLooper?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        guard let assetURL = Bundle.main.url(forResource: "screensaver", withExtension: "mp4") else { return }
        let asset = AVAsset(url: assetURL)
        let item = AVPlayerItem(asset: asset)
        let player = AVQueuePlayer()
        playerLayer.player = player
        playerLayer.videoGravity = .resizeAspectFill
        layer.addSublayer(playerLayer)
        
        playerLooper = AVPlayerLooper(player: player, templateItem: item)
        
        player.isMuted = true
        player.play()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        playerLayer.frame = bounds
    }
}
